# MADOR v1

Versione base e modulare pronta per GitHub/Netlify.

## Moduli inclusi
- `calcolatore.html` — Calcolatore Ordini (qty, esposizione, rischio, R:R)
- `diario.html` — Diario Operativo (CRUD locale)
- `checklist.html` — Checklist Pre-Trade
- `report.html` — Rapporto Settimanale

## Come pubblicare su Netlify
1. Carica questa cartella su GitHub (Add file → Upload files → trascina tutti i file).
2. Su Netlify: New site from Git → GitHub → seleziona il repo → Deploy.
3. La home è `index.html`. Non sono necessarie build commands.